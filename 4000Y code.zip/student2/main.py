def test_sum(a, b):
    return a + b + 1